package com.example.sandhyayalla.firebaseexample;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class SignUpactivity extends AppCompatActivity {
    DatabaseReference myRef;
    String useremail;
    Button btn_login1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_upactivity);
        btn_login1=(Button)findViewById(R.id.btn_login1);
        myRef = FirebaseDatabase.getInstance().getReference().child("users");

            btn_login1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                }
            });
        final EditText et_name=(EditText)findViewById(R.id.et_fname);
        final EditText et_lname=(EditText)findViewById(R.id.et_lastname);
        final EditText et_email=(EditText)findViewById(R.id.et_email);
        final EditText et_pwd=(EditText)findViewById(R.id.et_pwd1);
        final EditText et_repwd=(EditText)findViewById(R.id.et_repwd);
        Button btnsignup=(Button)findViewById(R.id.btnsign);
        btnsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (et_name.getText().toString().isEmpty()) {
                    et_name.setError("Enter first Name");
                }
                 else   if (et_lname.getText().toString().isEmpty()) {
                        et_lname.setError("Enter lastname Name");
                } else if (et_email.getText().toString().isEmpty()) {
                    et_email.setError("Enter Email");
                } else if (et_pwd.getText().toString().isEmpty()) {
                    et_pwd.setError("Enter password");
                }
                else if (et_repwd.getText().toString().isEmpty())
                {
                    et_repwd.setError("Repeat Password");
                }
                else if (!et_pwd.getText().toString().equals(et_repwd.getText().toString()))
                {
                   et_pwd.setError("Password and repeat password should match ");
                }
                else {

                     useremail=et_email.getText().toString();

                //Intent signupintent=new Intent(MainActivity.this,SignUpactivity.class);
                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        //User user1=dataSnapshot.getValue(User.class);
                        ArrayList<String> userlist=new ArrayList<String>();
                        for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                            User user = snapshot.getValue(User.class);
                            userlist.add(user.email);

                        }
                        Log.d("demo","usermails: "+userlist.toString());
                       if(userlist.contains(useremail))
                       {
                           //Toast.makeText(SignUpactivity.this, "Email already Exists", Toast.LENGTH_SHORT).show();
                           et_email.setText("");
                           et_email.setError("Email already Exists");
                       }
                       else
                       {
                           User user=new User(et_name.getText().toString(),et_lname.getText().toString(),et_email.getText().toString(),et_pwd.getText().toString());

                  myRef.push().setValue(user).addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void aVoid) {
                   // Log.d("demo","successfully saved data ");
                    Toast.makeText(SignUpactivity.this, "User has been Created", Toast.LENGTH_SHORT).show();
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(SignUpactivity.this, "unable to create Account "+e.toString(), Toast.LENGTH_SHORT).show();
                }
            });
                  userlist.clear();

                           Intent intent=new Intent(SignUpactivity.this,ChatRoomActivity.class);
                           intent.putExtra("user",user);
                           startActivity(intent);
                           et_email.setText("");
                           et_lname.setText("");
                           et_name.setText("");
                           et_pwd.setText("");
                           et_repwd.setText("");

                       }
                        //if(userlist.contains())


                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
            }
        });
    }
}
