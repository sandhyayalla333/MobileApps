package com.example.sandhyayalla.chatroom;

public class MessageItem {
    String fname,lname,userid,messageid,message,createdtime;

    @Override
    public String toString() {
        return "MessageItem{" +
                "fname='" + fname + '\'' +
                ", lname='" + lname + '\'' +
                ", userid='" + userid + '\'' +
                ", messageid='" + messageid + '\'' +
                ", message='" + message + '\'' +
                ", createdtime='" + createdtime + '\'' +
                '}';
    }

    public MessageItem()
    {}
}
